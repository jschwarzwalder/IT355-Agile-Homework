<?php

class Contact extends Controller {
	
	public function index(){
		echo 'contact index';
	}
	
	public function phone(){
		echo 'contact by phone';
	}
}